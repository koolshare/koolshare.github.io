#!/bin/sh

rm -f /koolshare/scripts/speedtest.sh
rm -f /koolshare/bin/speedtest
rm -f /koolshare/webs/Module_speedtest.asp
