#!/bin/sh

MODULE=koolnet

rm -f /koolshare/bin/$MODULE
rm -f /koolshare/scripts/config-$MODULE.sh
rm -f /koolshare/webs/Module_$MODULE.asp
rm -f /koolshare/init.d/S90$MODULE.sh
