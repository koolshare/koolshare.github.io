#! /bin/sh

sh /koolshare/swap/swap.sh check
