#！ /bin/sh

#start shellinaboxd
/koolshare/shellinabox/shellinaboxd --css=/koolshare/shellinabox/white-on-black.css -b
