#!/bin/sh

rm -rf /koolshare/softether
rm -rf /scripts/softether_config.sh
rm -rf /webs/Module_softether.asp

