#!/bin/sh

rm -rf /koolshare/appledns/*
rm /koolshare/scripts/appledns.sh
rm /koolshare/webs/Module_appledns.asp
