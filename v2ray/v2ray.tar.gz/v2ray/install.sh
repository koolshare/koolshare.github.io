#!/bin/sh

echo hahaha > /tmp/v2ray_test.txt
