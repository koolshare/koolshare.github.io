#!/bin/sh
killall ddnsto

rm -rf /koolshare/bin/ddnsto
rm -rf /koolshare/scripts/ddnsto_config.sh
rm -rf /koolshare/webs/Module_ddnsto.asp
rm -rf /koolshare/res/icon-ddnsto.png
rm -rf /koolshare/init.d/S70ddnsto.sh
