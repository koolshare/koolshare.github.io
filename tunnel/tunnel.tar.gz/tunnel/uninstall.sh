#!/bin/sh

MODULE=tunnel

rm -f /koolshare/bin/tunnel
rm -f /koolshare/scripts/config-tunnel.sh
rm -f /koolshare/webs/Module_tunnel.asp
rm -f /koolshare/init.d/S90tunnel.sh
