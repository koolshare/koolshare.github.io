#! /bin/sh

# just for test before release

touch /tmp/test.txt
echo test success! >> /tmp/test.txt
