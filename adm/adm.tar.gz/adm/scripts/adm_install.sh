#!/bin/sh

eval `dbus export adm`

sh /koolshare/adm/adm.sh install