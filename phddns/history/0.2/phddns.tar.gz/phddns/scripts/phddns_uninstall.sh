#!/bin/sh

rm -rf /koolshare/phddns
rm -rf /init.d/S60Phddns.sh
rm -rf /scripts/phddns_*.sh
rm -rf /webs/Module_phddns.asp
rm -rf /etc/PhMain.ini   
rm -rf /tmp/oray*

exit 0
