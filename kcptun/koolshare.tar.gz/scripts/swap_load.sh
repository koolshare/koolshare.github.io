#! /bin/sh

sh /koolshare/swap/swap.sh load
