#!/bin/sh

rm -rf /jffs/configs/dnsmasq.d/ps.conf
rm /koolshare/scripts/shadowvpn.sh
rm /koolshare/scripts/shadowvpn_client_up.sh
rm /koolshare/scripts/shadowvpn_client_down.sh
rm /koolshare/webs/Module_shadowvpn.asp
rm /koolshare/bin/shadowvpn