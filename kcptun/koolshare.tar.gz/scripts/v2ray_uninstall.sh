#!/bin/sh

if [ -d /koolshare/v2ray ];then
	sh /koolshare/v2ray/v2ray.sh uninstall
fi
