#!/bin/sh

ev=`dbus get __event__onwanstart_webshell`
if [ -z "$ev" ]; then
dbus event onwanstart_webshell /usr/bin/config-webshell.sh
fi

#pid=`ps|grep webshell|grep -v grep|awk '{print $1}'`
pid=`cat /tmp/.webshell-lock`
if [ -z "$1" ]; then
kill $pid || true
fi

if [ -z "$txt" ]; then
webshell -d 1 -f /tmp/.webshell-lock
else
echo $txt > /tmp/webshell.base64
webshell -c /tmp/webshell.base64 -d 1 -f /tmp/.webshell-lock
fi

