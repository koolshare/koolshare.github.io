#!/bin/sh


eval `dbus export v2ray`

if [ "$v2ray_enable" == "1" ];then
	/koolshare/v2ray/v2ray.sh restart
else
	/koolshare/v2ray/v2ray.sh stop
fi 