#!/bin/sh

/koolshare/v2ray/v2ray.sh update
