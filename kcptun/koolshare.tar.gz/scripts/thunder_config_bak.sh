#!/bin/sh
eval `dbus export thunder`

thunderPath=/koolshare/thunder
logFile=$thunderPath/getsysinfo
ifthunderExist=$(ps |grep vod_httpserver |grep -v grep)


if [ "$thunder_enable" = "1" ];then
	$thunderPath/portal >/dev/null 2>&1 &
	dbus set thunder_info="1"
	sleep 6
	#rm -rf /koolshare/thunder/getsysinfo
	info=`wget -q -O /koolshare/thunder/getsysinfo http://127.0.0.1:9000/getsysinfo`
	dbus set thunder_info="$info"
else
	$thunderPath/portal -s
fi
