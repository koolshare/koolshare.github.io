#!/bin/sh

rm -rf /koolshare/ddnspod
rm -rf /koolshare/scripts/ddnspod_config.sh
rm -rf /koolshare/webs/Module_ddnspod.asp
rm -rf /koolshare/res/icon-ddnspod.png
rm -rf /koolshare/res/md5.js
rm -rf /koolshare/res/rsa.js
rm -rf /koolshare/res/sha1.js
rm -rf /koolshare/scripts/ddnspod_config.sh
rm -rf /koolshare/init.d/S99ddnspod.sh
