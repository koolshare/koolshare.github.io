#!/bin/sh

config-webshell.sh check
