#!/bin/sh

rm -rf /koolshare/bin/kcp_router
rm -rf /koolshare/kcptun
rm -rf /koolshare/webs/Module_kcp.asp
rm -rf /koolshare/kcptun/perp/kcptun
rm -rf /koolshare/res/icon-kcp.png
rm -rf /koolshare/scripts/kcp_config.sh


