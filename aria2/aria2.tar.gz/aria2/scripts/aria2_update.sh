#!/bin/sh
sh /jffs/scripts/aria2_uninstall.sh
sh /jffs/scripts/aria2_uninstall.sh
