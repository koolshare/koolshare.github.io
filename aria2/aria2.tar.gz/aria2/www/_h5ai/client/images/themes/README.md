# Themes

This directory will contain any themes you add. At the moment there are only
icon themes supported. The folder structure is: `<theme-name>/<type>.<ext>`,
with `<ext>` one of `svg`, `png` or `jpg`.

To select a theme use the option `view > theme` in file `conf/options.json`.

You will find the previously included icon themes [here](https://github.com/lrsjng/h5ai-themes).
