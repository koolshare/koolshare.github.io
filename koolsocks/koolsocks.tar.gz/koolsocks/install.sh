#! /bin/sh
cd /tmp

cp -rf /tmp/koolsocks/res/* /koolshare/res/
rm -rf /tmp/koolsocks* >/dev/null 2>&1

