#!/bin/sh

rm -rf /koolshare/dw/*
rm /koolshare/scripts/dualwan_policy.sh
rm /koolshare/webs/Module_policy_route.asp
